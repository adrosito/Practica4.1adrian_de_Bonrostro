<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $numero = $_POST["numero"];
    $posicion = $_POST["posicion"];

    $errores = "";

    if (empty($nombre) || !preg_match("/^[a-zA-Z\s]+$/", $nombre)) {
        $errores .= "<p>Error: El nombre debe contener solo letras y espacios.</p>";
    }

    if (empty($numero) || !filter_var($numero, FILTER_VALIDATE_INT) || $numero < 0) {
        $errores .= "<p>Error: El número debe ser un entero positivo.</p>";
    }

    if ($errores) {
        echo "<h2>Errores en el formulario:</h2>";
        echo $errores;
        echo "<p><a href='index.html'>Volver al formulario</a></p>";
    } else {
        echo "<h2>Formulario Enviado Exitosamente</h2>";
        echo "<p>Nombre: " . htmlspecialchars($nombre) . "</p>";
        echo "<p>Número: " . htmlspecialchars($numero) . "</p>";
        echo "<p>Posición: " . htmlspecialchars($posicion) . "</p>";
        echo "<p><a href='index.html'>Enviar otro formulario</a></p>";
    }
} else {
    echo "<p>No se ha enviado ningún dato. <a href='index.html'>Volver al formulario</a></p>";
}
?>

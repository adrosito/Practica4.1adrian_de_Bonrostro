<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Desencriptar Mensaje</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.0.0/crypto-js.min.js"></script>
</head>
<body>
    <h1>Desencriptar Mensaje</h1>
    <form method="POST" action="">
        <textarea id="mensajeEncriptado" name="mensajeEncriptado" placeholder="Pega el mensaje encriptado aquí"></textarea><br>
        <button type="submit">Desencriptar</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $mensajeEncriptado = $_POST['mensajeEncriptado'];
        $clave = "clave-secreta"; // Debe ser la misma clave utilizada para encriptar
        echo "<p>Mensaje Desencriptado: <span id='mensajeDesencriptado'></span></p>";
        echo "<script>
            var mensajeEncriptado = '$mensajeEncriptado';
            var clave = '$clave';
            var bytes = CryptoJS.AES.decrypt(mensajeEncriptado, clave);
            var mensajeDesencriptado = bytes.toString(CryptoJS.enc.Utf8);
            document.getElementById('mensajeDesencriptado').innerText = mensajeDesencriptado;
        </script>";
    }
    ?>
    <button onclick="window.location.href='index.php'">Volver al Menú</button>

</body>
</html>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Encriptar Mensaje</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.0.0/crypto-js.min.js"></script>
</head>
<body>
    <h1>Encriptar Mensaje</h1>
    <form method="POST" action="">
        <textarea id="mensaje" name="mensaje" placeholder="Escribe tu mensaje aquí"></textarea><br>
        <button type="submit">Encriptar</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $mensaje = $_POST['mensaje'];
        $clave = "clave-secreta"; // Puedes cambiar esta clave
        echo "<p>Mensaje Encriptado: <span id='mensajeEncriptado'></span></p>";
        echo "<script>
            var mensaje = '$mensaje';
            var clave = '$clave';
            var mensajeEncriptado = CryptoJS.AES.encrypt(mensaje, clave).toString();
            document.getElementById('mensajeEncriptado').innerText = mensajeEncriptado;
        </script>";
    }
    ?>
    <button onclick="window.location.href='index.php'">Volver al Menú</button>

</body>
</html>

<?php
$result = $error = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $a = filter_input(INPUT_POST, 'a', FILTER_VALIDATE_INT, ["options" => ["min_range" => 0, "max_range" => 1]]);
    $b = filter_input(INPUT_POST, 'b', FILTER_VALIDATE_INT, ["options" => ["min_range" => 0, "max_range" => 1]]);

    if ($a === null || $b === null) {
        $error = "Por favor, introduce valores válidos (0 o 1).";
    } else {
        $and = $a & $b;
        $or = $a | $b;
        $xor = $a ^ $b;
        $result = "Resultados: AND=$and, OR=$or, XOR=$xor";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Puertas Lógicas</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Calculadora de Puertas Lógicas</h1>
    <form method="POST">
        <label for="a">Valor A (0 o 1):</label>
        <input type="text" id="a" name="a" value="<?= htmlspecialchars($_POST['a'] ?? '') ?>">
        <label for="b">Valor B (0 o 1):</label>
        <input type="text" id="b" name="b" value="<?= htmlspecialchars($_POST['b'] ?? '') ?>">
        <button type="submit">Calcular</button>
    </form>
    <?php if ($error): ?>
        <p class="error"><?= $error ?></p>
    <?php elseif ($result): ?>
        <h2><?= $result ?></h2>
    <?php endif; ?>
    <button onclick="window.location.href='index.php'">Volver al Menú</button>
</body>
</html>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Calcular Media, Moda y Mediana</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Calcular Media, Moda y Mediana</h1>
    <form method="POST" action="">
        <label for="valor1">Valor 1:</label>
        <input type="text" id="valor1" name="valores[]"><br>
        <label for="valor2">Valor 2:</label>
        <input type="text" id="valor2" name="valores[]"><br>
        <label for="valor3">Valor 3:</label>
        <input type="text" id="valor3" name="valores[]"><br>
        <label for="valor4">Valor 4:</label>
        <input type="text" id="valor4" name="valores[]"><br>
        <label for="valor5">Valor 5:</label>
        <input type="text" id="valor5" name="valores[]"><br>
        <button type="submit">Calcular</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $valores = $_POST['valores'];
        $valores = array_filter($valores, 'is_numeric');

        if (count($valores) != 5) {
            echo "<p>Error: Por favor, introduce 5 valores numéricos.</p>";
        } else {
            sort($valores);
            $media = array_sum($valores) / count($valores);

            $valores_count = array_count_values($valores);
            arsort($valores_count);
            $moda = array_key_first($valores_count);

            $mediana = $valores[2];

            echo "<p>Media: $media</p>";
            echo "<p>Moda: $moda</p>";
            echo "<p>Mediana: $mediana</p>";
        }
    }
    ?>

    <button onclick="window.location.href='index.php'">Volver al Menú</button>
</body>
</html>

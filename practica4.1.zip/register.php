<?php
$error = $result = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre = trim($_POST['nombre'] ?? '');
    $correo = filter_var($_POST['correo'], FILTER_VALIDATE_EMAIL);
    $descripcion = trim($_POST['descripcion'] ?? '');
    $opcion = $_POST['opcion'] ?? '';
    $intereses = $_POST['intereses'] ?? [];
    $foto = $_FILES['foto'] ?? null;

    if (empty($nombre) || empty($correo) || empty($descripcion) || empty($opcion) || empty($intereses) || !$foto) {
        $error = "Todos los campos son obligatorios.";
    } elseif (strlen($descripcion) > 300) {
        $error = "La descripción no puede superar los 300 caracteres.";
    } else {
        $upload_dir = "uploads/";
        $upload_file = $upload_dir . basename($foto['name']);

        if (move_uploaded_file($foto['tmp_name'], $upload_file)) {
            $result = "¡Inscripción realizada con éxito!";
        } else {
            $error = "Error al subir la foto.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Inscripción</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Formulario de Inscripción</h1>
    <form method="POST" enctype="multipart/form-data">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>" required>
        
        <label for="correo">Correo Electrónico:</label>
        <input type="email" id="correo" name="correo" value="<?= htmlspecialchars($_POST['correo'] ?? '') ?>" required>
        
        <label for="descripcion">Descripción:</label>
        <textarea id="descripcion" name="descripcion"><?= htmlspecialchars($_POST['descripcion'] ?? '') ?></textarea>
        
        <label for="foto">Fotografía:</label>
        <input type="file" id="foto" name="foto" required>
        
        <label for="opcion">Selecciona una Opción:</label>
        <select id="opcion" name="opcion">
            <option value="">--Selecciona--</option>
            <option value="opcion1">Opción 1</option>
            <option value="opcion2">Opción 2</option>
        </select>
        
        <label>Intereses:</label>
        <input type="checkbox" name="intereses[]" value="Deporte">Deporte
        <input type="checkbox" name="intereses[]" value="Música">Música
        <input type="checkbox" name="intereses[]" value="Tecnología">Tecnología
        
        <button type="submit">Registrar</button>
    </form>
    <?php if ($error): ?>
        <p class="error"><?= $error ?></p>
    <?php elseif ($result): ?>
        <h2><?= $result ?></h2>
    <?php endif; ?>
    <button onclick="window.location.href='index.php'">Volver al Menú</button>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Principal</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Bienvenido a la Plataforma de Ejercicios</h1>
    <p>Selecciona una de las siguientes opciones:</p>
    <ul>
        <li><a href="logic_gates.php">Calcular Puertas Lógicas</a></li>
        <li><a href="encrypt_message.php">Encriptar Mensaje</a></li>
        <li><a href="decrypt_message.php">Desencriptar Mensaje</a></li>
        <li><a href="math_operations.php">Calcular Media, Moda y Mediana</a></li>
        <li><a href="register.php">Formulario de Inscripción</a></li>
    </ul>
</body>
</html>
